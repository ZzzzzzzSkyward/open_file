local GLOBAL = _G or GLOBAL
GLOBAL.setmetatable(env, {
    __index = function(t, k)
        return GLOBAL.rawget(GLOBAL, k)
    end
})
local function IsNearTree(inst, radius)
    if inst ~= nil and inst:IsValid() then
        if not radius then
            radius = 50
        end
        local x, y, z = inst.Transform:GetWorldPosition()
        local musttags, canttags = {"shelter", "plant", "tree"}, nil
        local mustoneoftags = nil
        local ents = TheSim:FindEntities(x, y, z, radius, musttags, canttags, mustoneoftags)
        for i, v in ipairs(ents) do
            --print("found", v)
            if v.prefab and v.prefab:find("oceantree") then
                return true
            end
        end
    end
    return false
end
local function hackSleep(inst)
    local old = inst.OnEntitySleep
    inst.OnEntitySleep = function(inst)
        if IsNearTree(inst)==true then
            --print("do not sleep")
            return
        end
        --print("do sleep")
        old(inst)
    end
end
local cfg = {gnarwail = "gnarwail", shark = "shark"}
for k, v in pairs(cfg) do
    if GetModConfigData(v)=="true" then
        AddPrefabPostInit(v, hackSleep)
    end
end

