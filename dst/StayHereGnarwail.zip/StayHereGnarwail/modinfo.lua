name = "Gnarwail Stay Near Waterlog"
description = ""
author = "zzzzzzzs"
version = "20220519"
api_version_dst = 10
priority = 0
dont_starve_compatible = false
reign_of_giants_compatible = false
shipwrecked_compatible = false
dst_compatible = true
client_only_mod = false
server_only_mod = true
configuration = {
    {
        name = "gnarwail",
        options = {{description = "no", data = "false"}, {description = "yes", data = "true"}},
        default = "true"
    },
    {
        name = "shark",
        options = {{description = "no", data = "false"}, {description = "yes", data = "true"}},
        default = "true"
    }
}

translation = {
    {
        matchLanguage = function(lang)
            return lang == "zh" or lang == "zht" or lang == "zhr" or lang == "chs" or lang == "cht"
        end,
        translateFunction = function(key)
            return translation[1].dict[key] or nil
        end,
        dict = {
            name = "留下来吧一角鲸",
            unusable = "不可用",
            description = [[
让一角鲸住在水中木周围.
]],
            gnarwail = "一角鲸",
            shark = "鲨鱼"
        }
    },
    {
        matchLanguage = function(lang)
            return lang == "en"
        end,
        dict = {
            name = "Gnarwail Stay Near Waterlog",
            description = [[
Let Gnarwail Stay Near Waterlog.
]]
        },
        translateFunction = function(key)
            return translation[2].dict[key] or key
        end
    }
}
local function makeConfigurations(conf, translate, baseTranslate)
    local index = 0
    local config = {}
    local function trans(str)
        return translate(str) or baseTranslate(str)
    end

    local string = ""
    local keys = {
        letter = {
            "A",
            "B",
            "C",
            "D",
            "E",
            "F",
            "G",
            "H",
            "I",
            "J",
            "K",
            "L",
            "M",
            "N",
            "O",
            "P",
            "Q",
            "R",
            "S",
            "T",
            "U",
            "V",
            "W",
            "X",
            "Y",
            "Z"
        },
        number = {"0", "1", "2", "3", "4", "5", "6", "7", "8", "9"},
        fn = {"F1", "F2", "F3", "F4", "F5", "F6", "F7", "F8", "F9", "F10", "F11", "F12"},
        mod = {"LAlt", "RAlt", "LCtrl", "RCtrl", "LShift", "RShift"},
        func = {
            "Backspace",
            "Insert",
            "Home",
            "Delete",
            "End",
            "Pageup",
            "Pagedown",
            "Print",
            "Scrollock",
            "Pause",
            "Tab",
            "Capslock",
            "Space"
        },
        punctuation = {
            "Minus",
            "Equals",
            "Period",
            "Slash",
            "Semicolon",
            "Leftbracket",
            "Rightbracket",
            "Tiled",
            "Backslash",
            "Up",
            "Down",
            "Left",
            "Right"
        }
    }
    for i = 1, #conf do
        local v = conf[i]
        if not v.disabled then
            index = index + 1
            config[index] = {
                name = v.name or "",
                label = v.name ~= "" and translate(v.name) or (v.label and trans(v.label)) or "",
                hover = v.name ~= "" and (v.hover and trans(v.hover)) or nil,
                default = v.default or "",
                options = {{description = "", data = ""}},
                client = v.client or false
            }
            if v.unusable then
                config[index].label = config[index].label .. "[" .. trans("unusable") .. "]"
            end
            if v.key then
                local keylist = {}
                for j = 1, #v.key do
                    local key = v.key[j]
                    local kl = keys[key]
                    for k = 1, #kl do
                        keylist[#keylist + 1] = {description = kl[k], data = "KEY_" .. string.upper(kl[k])}
                    end
                end
                keylist[#keylist + 1] = {description = "Disabled", data = false}
                config[index].options = keylist
                config[index].is_keylist = true
                config[index].default = false
            elseif v.options then
                for j = 1, #v.options do
                    local opt = v.options[j]
                    config[index].options[j] = {
                        description = opt.description and trans(opt.description) or "",
                        hover = opt.hover and trans(opt.hover) or "",
                        data = opt.data ~= nil and opt.data or ""
                    }
                end
            end
        end
    end
    configuration_options = config
end

local function makeInfo(translation)
    local localName = translation("name")
    local localDescription = translation("description")
    if localName then
        name = localName
    end
    if localDescription then
        description = localDescription
    end
end

local function getLang()
    local string = ""
    local lang = string.lower(locale) or "en"
    return lang
end

local function generate()
    local lang = getLang()
    local localTranslation = translation[#translation].translateFunction
    local baseTranslation = translation[#translation].translateFunction
    for i = 1, #translation - 1 do
        local v = translation[i]
        if v.matchLanguage(lang) then
            localTranslation = v.translateFunction
            break
        end
    end
    makeInfo(localTranslation)
    makeConfigurations(configuration, localTranslation, baseTranslation)
end

generate()
