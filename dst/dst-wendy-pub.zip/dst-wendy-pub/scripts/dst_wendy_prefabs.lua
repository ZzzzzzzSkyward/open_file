return {
    "abigail",
    "abigail_flower",
    "ghostflower",
    "ghostly_elixirs",
    "wendy",
    "sisturn",
    "abigailforcefield",
    "abigail_attack_fx",
    "dst_wendy_fx",
    "reviver"
}
