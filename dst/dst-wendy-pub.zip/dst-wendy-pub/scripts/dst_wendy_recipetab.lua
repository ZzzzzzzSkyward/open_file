return {
    {
        str = "ELIXIRBREWING",
        name = "Ectoherbology",
        sort = 12,
        priority = 12,
        icon = "tab_elixirbrewing.tex",
        atlas = "images/tabs_dst.xml",
        builder_tag = "elixirbrewer", -- added
        crafting_station = true -- added
    }
}
