
local SummoningItem = Class(function(self, inst)
    self.inst = inst
end)

return SummoningItem
