-- from mod SW Character 697356989
return {
    DESCRIBE = {
        ABIGAIL = {
            LEVEL1 = {"A lady specter!", "A lady specter!"},
            LEVEL2 = {"A lady specter!", "A lady specter!"},
            LEVEL3 = {"A lady specter!", "A lady specter!"}
        },
        ABIGAIL_FLOWER = {
            GENERIC = "A bewitched flower a soul whut been lost!",
            LEVEL1 = "It ain't wantin' no scallywags about!",
            LEVEL2 = "I's sees some devil magics comin' about.",
            LEVEL3 = "Thet flower be givin' Woodlegs a spook!",
            -- deprecated
            LONG = "Somethin' be dyin' ta get out.",
            MEDIUM = "I's sees some devil magics comin' about.",
            SOON = "Thet flower be givin' Woodlegs a spook!",
            HAUNTED_POCKET = "I don't think it be likin' me pockets.",
            HAUNTED_GROUND = "Thet flower be a spectre!"
        },
        GHOSTLYELIXIR_SLOWREGEN = "A sickly brew.",
        GHOSTLYELIXIR_FASTREGEN = "A sickly brew.",
        GHOSTLYELIXIR_SHIELD = "A sickly brew.",
        GHOSTLYELIXIR_ATTACK = "A sickly brew.",
        GHOSTLYELIXIR_SPEED = "A sickly brew.",
        GHOSTLYELIXIR_RETALIATION = "A sickly brew.",
        SISTURN = {
            GENERIC = "Needs a flower 'er two.",
            SOME_FLOWERS = "Sorry lass, all I's got is kelp!",
            LOTS_OF_FLOWERS = "A proper burial is 'un out at sea!"
        },
        GHOSTFLOWER = "Arrg! It be a ghostly flower!"
    },
    ACTIONFAIL = {
        GIVE = {
            ABIGAILHEART = "Best be leavin' th'spirits be.",
            GHOSTHEART = "Thet won't calm this ol'spirit!"
        }
    }
}
