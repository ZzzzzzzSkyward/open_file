return {
    DESCRIBE = {
        ABIGAIL = {
            LEVEL1 = "唉，可怜的鬼魂！",
            LEVEL2 = "唉，可怜的鬼魂！",
            LEVEL3 = "唉，可怜的鬼魂！"
        }
    }
}
