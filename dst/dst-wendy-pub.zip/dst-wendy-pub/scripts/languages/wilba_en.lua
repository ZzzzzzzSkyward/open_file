return {
    DESCRIBE = {
        ABIGAIL = {
            LEVEL1 = "ALAS, POOR GHOST!",
            LEVEL2 = "ALAS, POOR GHOST!",
            LEVEL3 = "ALAS, POOR GHOST!"
        }
    }
}
