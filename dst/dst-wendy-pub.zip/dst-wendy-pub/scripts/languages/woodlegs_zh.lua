-- from mod SW Character 697356989
return {
    DESCRIBE = {
        ABIGAIL = {
LEVEL1 = { "一个女幽灵！","一个幽灵女士！"},
LEVEL2 = { "一个女幽灵！","一个幽灵女士！"},
LEVEL3 = { "一个女幽灵！","一个幽灵女士！"}
        },
        ABIGAIL_FLOWER = {
            GENERIC = "一朵被迷住的花朵，一个失去的灵魂！",
            LEVEL1 = "它不想要任何淘气鬼！",
            LEVEL2 = "我看到一些恶魔魔法即将来临。",
            LEVEL3 = "内朵花吓坏了伍德莱格！",
            -- 已弃用
            LONG = "有什么东西不想出去。",
            MEDIUM = "我看到一些恶魔魔法即将来临。",
            SOON = "内朵花吓坏了伍德莱格！",
            HAUNTED_POCKET = "我不认为它喜欢我的口袋。",
            HAUNTED_GROUND = "那花是个幽灵！"
        },
        GHOSTLYELIXIR_SLOWREGEN = "一种恶心的啤酒。。",
        GHOSTLYELIXIR_FASTREGEN = "一种恶心的啤酒。",
        GHOSTLYELIXIR_SHIELD = "一种恶心的啤酒。",
        GHOSTLYELIXIR_ATTACK = "一种恶心的啤酒。",
        GHOSTLYELIXIR_SPEED = "一种恶心的啤酒。",
        GHOSTLYELIXIR_RETALIATION = "一种恶心的啤酒。",
        SISTURN = {
            GENERIC = "需要一朵花么两朵花。",
            SOME_FLOWERS = "对不起姑娘，我只有海带！",
            LOTS_OF_FLOWERS = "一个合适的葬礼得在海上！"
        },
        GHOSTFLOWER = "啊！这是一朵幽灵花！"
    },
    ACTIONFAIL = {
        GIVE = {
            ABIGAILHEART = "最好让这些灵魂保持原样。",
            GHOSTHEART = "这个不会让这个人的灵魂冷静下来的。"
        }
    }
}
