-- from mod HAM Character 2399658326
return {
    DESCRIBE = {
        ABIGAIL = {
            LEVEL1 = {"Yeah, that's natural. Supernatural.", "Poor Wendy..."},
            LEVEL2 = {"Yeah, that's natural. Supernatural.", "It must've been real hard on Wendy when Abigail..."},
            LEVEL3 = {"Yeah, that's natural. Supernatural.", "You keep Wendy safe, y'hear?"}
        },

        ABIGAIL_FLOWER = {
            GENERIC = "A totally normal flower. Yeah. That's what it is.",
            LEVEL1 = "A budding flower. How nice.",
            LEVEL2 = "Not sure I've seen that kind of flower around here.",
            LEVEL3 = "It's ready for something.",

            -- deprecated
            LONG = "A budding flower. How nice.",
            MEDIUM = "Not sure I've seen that kind of flower around here.",
            SOON = "It's ready for something.",
            HAUNTED_POCKET = "It's trying to get out. Understandable.",
            HAUNTED_GROUND = "Is there some kind of magic trick to it?"
        },
        GHOSTFLOWER = "As far as ghost flowers go this one takes the cake.",
        SMALLGHOST = "Hey, what's haunting you? Sorry, that was poor taste.",

        GHOSTLYELIXIR_SLOWREGEN = "A drink for the supernatural.",
        GHOSTLYELIXIR_FASTREGEN = "It's all the craze in the ghost-world.",
        GHOSTLYELIXIR_SHIELD = "A ghostly drink for a ghostly gal.",
        GHOSTLYELIXIR_ATTACK = "That's Wendy's little experiment.",
        GHOSTLYELIXIR_SPEED = "It has an... Interesting smell.",
        GHOSTLYELIXIR_RETALIATION = "I hope Wendy doesn't mix that with our food...",
        SISTURN = {
            GENERIC = "Poor Abigail died being a bit too adventorous. When will my end come?",
            SOME_FLOWERS = "I should add a few flowers to it.",
            LOTS_OF_FLOWERS = "Abigail will always live on in your heart, Wendy."
        }
    },
    ACTIONFAIL = {
        GIVE = {
            ABIGAILHEART = "Sorry, Wendy. I tried.",
            GHOSTHEART = "Bummer, that guy's staying heartless."
        }
    }
}
