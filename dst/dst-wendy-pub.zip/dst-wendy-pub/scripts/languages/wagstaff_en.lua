-- from mod HAM Character 2399658326
return {
    DESCRIBE = {
        ABIGAIL = {
            GENERIC = "She seems to be stuck in ectoplasmic form."
        },
        ABIGAIL_FLOWER = {
            GENERIC = "Emitting a psychokinetic energy.",
            LEVEL1 = "Appears dormant.",
            LEVEL2 = "Not in full bloom just yet.",
            LEVEL3 = "What psychokinetic force is keeping it afloat?",

            LONG = "Appears dormant.",
            MEDIUM = "Not in full bloom just yet.",
            SOON = "What psychokinetic force is keeping it afloat?",
            HAUNTED_POCKET = "The energy cannot be contained.",
            HAUNTED_GROUND = "Requires a sacrifice for a reactant."
        }
    }
}
