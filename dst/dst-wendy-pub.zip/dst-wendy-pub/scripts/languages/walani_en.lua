-- from mod SW Character 697356989
return {
    DESCRIBE = {
        ABIGAIL = {
            LEVEL1 = "Hang ten, ectobuddy.",
            LEVEL2 = "Hang ten, ectobuddy.",
            LEVEL3 = "Hang ten, ectobuddy."
        },
        ABIGAIL_FLOWER = {
            GENERIC = "That's a pretty wicked flower.",
            LEVEL1 = "I think we all could use a little alone time now and then.",
            LEVEL2 = "You comin' out of your floral shell? No pressure, bud.",
            LEVEL3 = "Out and about today, ectobuddy?",
            -- deprecated
            LONG = "Something's up with that flower.",
            MEDIUM = "I don't feel comfortable chillin' around it.",
            SOON = "Something is getting ready to bloom.",
            HAUNTED_POCKET = "I should probably put this down.",
            HAUNTED_GROUND = "That flower's still pretty cool."
        },
        GHOSTLYELIXIR_SLOWREGEN = "Nice brew, dude.",
        GHOSTLYELIXIR_FASTREGEN = "Nice brew, dude.",
        GHOSTLYELIXIR_SHIELD = "Nice brew, dude.",
        GHOSTLYELIXIR_ATTACK = "Nice brew, dude.",
        GHOSTLYELIXIR_SPEED = "Nice brew, dude.",
        GHOSTLYELIXIR_RETALIATION = "Nice brew, dude.",
        SISTURN = {
            GENERIC = "Maybe I'll send some flowers out to sea for my brother...",
            SOME_FLOWERS = "I know of some real red flowers that'd look great on it.",--rad?
            LOTS_OF_FLOWERS = "I bet she loves it."
        },
        GHOSTFLOWER = "That's one mystical flower."
    },
    ACTIONFAIL = {
        GIVE = {
            ABIGAILHEART = "At least I tried, right? That's one thing worth the effort.",
            GHOSTHEART = "Bummer, that guy's staying heartless."
        }
    }
}
