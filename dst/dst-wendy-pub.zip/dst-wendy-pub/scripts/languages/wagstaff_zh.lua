-- from mod HAM Character 2399658326
return {
    DESCRIBE = {
        ABIGAIL = {
           GENERIC = "她似乎被困在了灵质形态。"
},
ABIGAIL_FLOWER = {
GENERIC = "释放精神动能。",
LEVEL1 = "显示为休眠状态。",
LEVEL2 = "还没有完全开放。",
LEVEL3 = "是什么心理动力让它漂浮在水面上？",

LONG = "似乎处于休眠状态。",
MEDIUM = "还没有完全开放。",
SOON ="是什么心理动力让它漂浮着？",
HAUNTED_POCKET = "能量无法遏制。",
HAUNTED_GROUND = "需要牺牲一个反应物。"
        }
    }
}
