-- from mod SW Character 697356989
return {
    DESCRIBE = {
        ABIGAIL = {
            LEVEL1 = "板尖骑行来不来，灵体伙计。",
            LEVEL2 = "板尖骑行来不来，灵体伙计。",
            LEVEL3 = "板尖骑行来不来，灵体伙计。"
        },
        ABIGAIL_FLOWER = {
            GENERIC = "那是一朵非常邪恶的花。",
            LEVEL1 = "我想我们都可以时不时地独处一会儿。",
            LEVEL2 = "你从你的花壳里出来了吗？别有压力，伙计。",
            LEVEL3 = "今天出去走走吗，灵体伙计？",
            -- deprecated
            LONG = "那朵花出事了。",
            MEDIUM = "我觉得在它周围冷着不舒服。",
            SOON = "有些东西正准备绽放。",
            HAUNTED_POCKET = "我也许应该把这个放下。",
            HAUNTED_GROUND = "那朵花还是挺酷的。"
        },
        GHOSTLYELIXIR_SLOWREGEN = "好酒，老兄。",
        GHOSTLYELIXIR_FASTREGEN = "好酒，老兄。",
        GHOSTLYELIXIR_SHIELD = "好酒，老兄。",
        GHOSTLYELIXIR_ATTACK = "好酒，老兄。",
        GHOSTLYELIXIR_SPEED = "好酒，老兄。",
        GHOSTLYELIXIR_RETALIATION = "好酒，老兄。",
        SISTURN = {
            GENERIC = "也许我会送些花出海给我哥哥...",
            SOME_FLOWERS = "我知道一些真正的红花，戴在上面会很好看。",
            LOTS_OF_FLOWERS = "我敢打赌她喜欢它"
        },
        GHOSTFLOWER = "这是一种神秘的花。"
    },
    ACTIONFAIL = {
        GIVE = {
            ABIGAILHEART = "至少我努力过，对吧？这是值得努力的一件事。",
            GHOSTHEART = "可恶，那家伙还是没心没肺。"
        }
    }
}
