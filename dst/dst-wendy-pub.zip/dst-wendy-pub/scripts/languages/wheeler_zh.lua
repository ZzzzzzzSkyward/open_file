-- from mod HAM Character 2399658326
return {
    DESCRIBE = {
        ABIGAIL = {
            LEVEL1 = {"是啊，那很自然。超自然。", "可怜的温蒂……"},
            LEVEL2 = {"是啊，那很自然。超自然。", "当阿比盖尔……的时候温蒂一定很难过。"},
            LEVEL3 = {"是啊，那很自然。超自然。", "你要保证温蒂的安全，听到了吗？"}
        },

        ABIGAIL_FLOWER = {
            GENERIC = "一朵完全正常的花。是啊。就是这么回事。",
            LEVEL1 = "含苞待放的花朵。多好啊。",
            LEVEL2 = "我不确定我在这附近见过那种花。",
            LEVEL3 = "它已经准备好了。",

            -- 已弃用
            LONG = "含苞待放的花。多好啊。",
            MEDIUM = "我不确定我在这附近见过那种花。",
            SOON = "它已经准备好了。",
            HAUNTED_POCKET = "它想出去。可以理解。",
            HAUNTED_GROUND = "有什么魔法吗？"
        },
        GHOSTFLOWER = "就鬼的花而言，这朵花是最棒的。",
        SMALLGHOST = "嘿，你在想什么？不好意思，那是品味差。",

        GHOSTLYELIXIR_SLOWREGEN = "超自然生物的饮品。",
        GHOSTLYELIXIR_FASTREGEN = "这是鬼界的所有狂热。",
        GHOSTLYELIXIR_SHIELD = "幽灵女孩的幽灵饮料。",
        GHOSTLYELIXIR_ATTACK = "那是温蒂的小实验。",
        GHOSTLYELIXIR_SPEED = "它有一个...有意思的味道。",
        GHOSTLYELIXIR_RETALIATION = "我希望温蒂不要把那个和我们的食物混在一起...",
        SISTURN = {
            GENERIC = "可怜的阿比盖尔死得有点太冒险了。我的末日何时到来？",
            SOME_FLOWERS = "我应该给它加几朵花。",
            LOTS_OF_FLOWERS = "阿比盖尔永远活在你的心中，温蒂。"
        }
    },
    ACTIONFAIL = {
        GIVE = {
            ABIGAILHEART = "对不起，温蒂。我试过了。",
            GHOSTHEART = "可恶，那家伙一直没心没肺。"
        }
    }
}
