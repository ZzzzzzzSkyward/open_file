return {
    inventoryimages_dst_wendy = { "abigail_flower_level0","abigail_flower_old",
                                 "abigail_flower_level2", "abigail_flower_level3",  "ghostflower",
                                 "ghostlyelixir_attack", "ghostlyelixir_fastregen", "ghostlyelixir_retaliation",
                                 "ghostlyelixir_shield", "ghostlyelixir_slowregen", "ghostlyelixir_speed", "sisturn"},
    inventoryimages_dst_reviver = {"reviver"},
    tabs_dst = {"elixirbrewing"}
}
