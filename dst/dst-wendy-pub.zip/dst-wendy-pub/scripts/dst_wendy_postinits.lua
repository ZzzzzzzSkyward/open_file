return {
    prefab = {"abigail", "ghost"},
    component = {"sanity", "follower", "health", "combat", "trader", "leader", "perishable"},
    widget = {"statusdisplays"},
    screens = {},
    brain = {"ghost"},
    root = {}
}
