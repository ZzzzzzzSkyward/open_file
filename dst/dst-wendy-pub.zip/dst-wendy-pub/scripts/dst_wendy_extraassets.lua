return { { "ANIM", "swap_paddle" }, { "ANIM", "status_abigail" }, { "ANIM", "status_meter" },
        { "ANIM", "status_meter_circle" },
        { "IMAGE", "tabs_dst" }, { "ATLAS", "tabs_dst" }, { "IMAGE", "sisturn_slot_petals" },
        { "ATLAS", "sisturn_slot_petals" } }
