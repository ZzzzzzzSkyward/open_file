[h1]Wendy's Character Refresh is Now Available![/h1]
Wendy clutches tightly to the memory of her twin sister, Abigail. Some days, it’s almost as if she never left…

Even from the afterlife, Abigail never stopped looking out for Wendy - and now Wendy has discovered how to return the favor. Her affinity with the supernatural has led her to the mysterious practice of Ectoherbology, allowing her to create haunting elixirs to aid her sister beyond the veil and make their bond stronger than ever before.

Here are some of the details:
[list]
[*]Wendy carries a flower that can summon her sister Abigail's spirit. If there is no other Abigail's flower in the world, you will get another the next time the game loads. Also you can craft one in the magic tab for 1 mourning glory + 1 nightmare fuel.
[*]Abigail's spirit gets stronger over time but starts over if she is destroyed. The details are as follows:
[list]
[*]In the first stage, Abigail has 150 hp. This stage lasts 1 day.
[*]In the second stage, Abigail has 300 hp, and emits faint light. This stage lasts 1 day.
[*]In the last stage, Abigail has 600 hp, and emits medium light. When Abigail is dead her stage resets to the first.
[*]Flowerful sisturn can speed up the process.
[*]Ectoherbology can help Abigail fight bosses easier.
[/list]
[*]Abigail's attack besets her opponents with ghostly petals for a short period of time. The details are as follows:
[list]
[*]The affected enemies receives 1.1x damage.
[*]Wendy gains 0.4x extra damage fighting together with Abigail.
[/list]
[*]Abigail creates a shield after being hit. The details are as follows:
[list]
[*]The shield absorbs 100% damage.
[*]Ectoherbology helps Abigail strengthen her shield.
[/list]
[*]Wendy can ask Abigail to stay close to her or roam more free via Abigail's flower. The details are as follows:
[list]
[*]Wendy can soothe Abigail via Abigail's flower, she will refuse to attack unless enemies are close to Wendy. However, if there is a prey or a monster, she will actively attack it.
[*]Wendy can encourage Abigail via Abigail's flower, she will stay away from Wendy and attack everything in sight.
[*]In both states Abigail will not insist her attack intention if Wendy is too far away.
[/list]
[*]Wendy does not lose sanity due to ghosts.
[*]Ghosts including Ancient Spirits are friendly to Wendy.
[*]Wendy has reduced damage in combat, but suffers less sanity drain from auras and the dark. The details are as follows:
[list]
[*]Wendy has 0.75x damage dealt.
[*]Wendy has 0.75x sanity drain rate.
[/list]
[*]Wendy has her special Ectoherbology learned from books. The details are as follows:
[list]
[*]Nightshade Nostrum raises Abigail's damage to 40(night or cave), compared to 15 in day and 25 in dusk.
[*]Spectral Cure-All cures Abigail 20hp/s for a total of 600hp.
[*]Distilled Vengeance strengthen Abigail's shield so it deals 20 damage to attackers each time.
[*]Unyielding Draught lengthens the duration of Abigail's shield.
[*]Revenant Restorative cures Abigail 2hp/s for a total of 960hp.
[*]Vigor Mortis speeds Abigail up from 5(slow-walking Wilson speed) to 8.75, compared to 6(normal Wilson speed).
[*]Mourning Glory is required. And you can get them from petals in sisturn when they spoils.
[/list]
[*]Wendy can build sisturn to mourn. Put petals in it and when it is full of flower Wendy and Abigail will feel more connected to each other. Petal will become mourning glory when it spoils.
[*]No pipspook.
[*]Wendy's skins, Abigail's skins, Abigail's flower's skins are available now. You need to enable [DST]Skin System and the relevant data mod. The details are as follows:
[list]
[*]Use clean sweeper to swap skins.
[*]Craft clean sweeper for 1 twig + 4 petals with a researchlab, in the survival tab. The recipe follows the QoL made by Klei.
[*]Use wardrobe to change character skin.
[/list]
[img]https://cdn.forums.klei.com/monthly_2020_03/wendypostart_sm.png.b7c139c96c99eeb7911e300564cbf5dc.png[/img]
[/list]
[h1]Dependency[/h1]
[list]
[*]DST Library [url]https://steamcommunity.com/sharedfiles/filedetails/?id=2890042663[/url]
[/list]
[h1]Known Issues[state][/h1]
[list]
[*]SW boat animation is missing boat layer, but it is too complicated to fix. Maybe I will solve this when I have enough spare time.[won't fix]
[*]No water animation for Abigail's flower and ghostlyelixirs.[won't fix]
[*]Can't use health as an ingredient in RoG and vanilla.[won't fix]
[*]language file is missing strings for DS-only characters.[won't fix]
[*]Abigail and her FX are missing sound effects, but I don't how to extract them.[unable to fix]
[*]anim_bloom_ghost.ksh cannot be applied which results in crash, I don't know why.[unable to fix]
[*]Do not use fire staff to attack Abigail in RoG and vanilla.
[/list]
[h1]Compatibility[/h1]
[list]
[*]Not with any mod overriding abigail.lua, wendy.lua, abigail_flower.lua.
[*]Not with Telltale Heart mods, this mod has a reviver prefab and will collide.
[*]Crash with "Eggpain Action Queue". Solution: workshop-692094647\td1madao\td1madao_global_lib.lua:28 local a = _G.TD[AUTHOR]
[*]Beware any other mod that ports DST assets, if the game crash please disable all mods and re-enable them. Known collision: Nautical HUD, Forge HUD, Victorian HUD, Rose HUD.
[/list]
[DST]温蒂重做

[h1]温蒂人物更新！[/h1]
多希望你在
温蒂对她孪生姐妹阿比盖尔念念不忘。有时候，好像她从未离开一样……
虽然天人永隔，但是阿比盖尔从未停止过照顾温蒂——而现在温蒂终于找到了回报的方法。她与超自然能力的亲近引领她掌握了神秘的灵体草药，让她得以创造出强力药剂，越过面纱帮助她的姐妹，让她们彼此之间的纽带更加坚固。
以下是更多细节:
[list]
[*]温蒂携带一朵花，能够召唤姐妹阿比盖尔的灵魂。如果世界里一朵阿比盖尔之花也没有，下次加载游戏时你会重新获得一朵。同时你也可以在魔法制作栏里用1个哀悼荣耀+1个噩梦燃料制作。
[*]阿比盖尔的灵魂会随着时间逐渐增强，但是一旦死亡，就会重新来过。细节如下：
[list]
[*]第一阶段阿比盖尔有150血量。该阶段持续一天。
[*]第二阶段阿比盖尔有300血量，并发出微弱的光。该阶段持续一天。
[*]第二阶段阿比盖尔有600血量，并发光。阿比盖尔死亡后回到第一阶段。
[*]满是花朵的姐妹骨灰坛能够加快进程。
[*]灵体药水学能够帮助阿比盖尔更容易地打boss。
[/list]
[*]阿比盖尔的攻击在短时间内用幽灵的花瓣包围敌人。细节如下：
[list]
[*]受影响的敌人受到1.1倍的伤害。
[*]温蒂与阿比盖尔一起战斗时攻击力提高到1.4倍。
[/list]
[*]阿比盖尔在被攻击时生成一个短暂的护盾。细节如下：
[list]
[*]护盾吸收100%伤害。
[*]灵体药水学能够帮助阿比盖尔加强她的护盾。
[/list]
[*]温蒂可以通过阿比盖尔之花让阿比盖尔靠近她，或者更自由的飘动。细节如下：
[list]
[*]温蒂可以通过阿比盖尔之花来安抚阿比盖尔，除非敌人靠近温蒂，否则她不攻击。但是如果周围有猎物或怪物，她会主动攻击。
[*]温蒂可以通过阿比盖尔之来怂恿阿比盖尔，她会远离温蒂，攻击视线范围内的一切。
[*]如果温蒂离得太远，阿比盖尔在这两个状态都不会坚持她的攻击意图。
[/list]
[*]温蒂不会因为鬼魂减少理智值。
[*]鬼魂与远古之魂不会主动攻击温蒂。
[*]温蒂的战斗伤害降低，但是由于降san光环和黑暗引起的理智降低减少。
[list]
[*]温蒂攻击伤害为0.75威.
[*]温蒂理智降低速率为0.75威。
[/list]
[*]温蒂从书中学到了特殊技能灵体药水学。细节如下：
[list]
[*]夜影万金油将阿比盖尔的伤害提高到40（相当于夜间或洞穴），而白天为15，黄昏为25。
[*]灵魂万灵药治疗阿比盖尔20hp/s，总共600hp。
[*]蒸馏复仇强化了阿比盖尔的护盾，每次对攻击者造成20点伤害。
[*]不屈药剂延长阿比盖尔的护盾持续时间。
[*]亡者补药以2hp/s的速度治愈阿比盖尔，总计960hp。
[*]强健精油将阿比盖尔的速度从5（缓慢行走的威尔逊速度）提高到8.75，正常值为6（正常的威尔逊速度）。
[*]哀悼荣耀是必需的。你可以让花瓣在姐妹骨灰罐里腐烂来获取它。
[/list]
[*]温蒂可以制作姐妹骨灰罐来悼念。当它满是花朵时，温蒂和阿比盖尔会感到她们的联系更加紧密。花瓣在姐妹骨灰罐里腐烂后会化作哀悼荣耀。
[*]没有小惊吓。
[*]温蒂、阿比盖尔、阿比盖尔之花的皮肤已经可获取。需要同时开启[DST]皮肤系统与相应的数据mod。细节如下：
[list]
[*]使用清洁扫把交换皮肤。
[*]在生存制作栏中，在炼金引擎旁用1树枝+4花瓣制作扫把。配方遵循Klei的生活质量更新。
[*]使用衣柜来更换人物皮肤。
[/list]
[img]https://cdn.forums.klei.com/monthly_2020_03/wendypostart_sm.png.b7c139c96c99eeb7911e300564cbf5dc.png[/img]
[/list]
[h1]依赖项[/h1]
[list]
[*]联机库 [url]https://steamcommunity.com/sharedfiles/filedetails/?id=2890042663[/url]
[/list]
[h1]兼容性
[/h1]
[list]
[*]联机库mod关闭了严格模式，导致蛋疼排队论出错，解决办法：workshop-692094647\td1madao\td1madao_global_lib.lua第28行改成 local a = _G.TD[AUTHOR]
[*]不兼容用覆盖法覆盖wendy.lua、abigail.lua、abigail_flower.lua的mod。
[*]不兼容搬运了告密的心的mod。
[*]当心其他搬运联机内容的mod。如果直接闪退请尝试禁用所有mod重新勾选一遍。已知冲突mod：Nautical HUD、Forge HUD、Victorian HUD、Rose HUD。
[*]不要使用火魔杖在巨人国及原版世界攻击阿比盖尔。
[/list]
[h1]已知问题[状态][/h1]
[list]
[*]船上动画缺失船的图层，但因为过于复杂，以后我有空再说。[不修]
[*]阿比盖尔之花、药水没有水上动画。[不修]
[*]RoG与原版不能使用血量作为材料。[不修]
[*]语言文件缺少仅存在于单机的角色的句子。[不修]
[*]阿比盖尔缺失音效，但是我不知道如何提取文件。[不会修]
[*]anim_bloom_ghost.ksh滤镜无法使用，会导致崩溃，我不知道为什么。[不会修]
[/list]