return {widget = {"image", "uianim", "containerwidget"}, component = {"inventory", "spellcaster", "inventoryitem"}}
