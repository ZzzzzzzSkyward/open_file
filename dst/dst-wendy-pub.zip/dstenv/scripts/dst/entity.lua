local Entity = Entity
function Entity:AddNetwork()
end
function Entity:SetPristine()
end
Entity.AddVFXEffect = Entity.AddParticleEmitter
