return {
    prefab = {},
    components = {"locomotor", "container", "playercontroller"},
    widgets = {"itemtile", "mapwidget"},
    screens = {"mapscreen"},
    brain = {},
    root = {"playerprofile"}
}
